#ifndef PATH_H
#define PATH_H

#include <stdexcept>
#include "package.h"
#include "dinArray.h"

class Path{
    int packageId;
    dinArray<char> stops;
    int nOfStops;

    public:
        Path():packageId(-1),stops(dinArray<char>(0)), nOfStops(0){}
        Path(int id, char* newStops, int n):packageId(id), stops(dinArray<char>(n)), nOfStops(n){
            for (int i = 0; i < n; i++)
            {
                stops[i] = newStops[i];
            }
        }

        char operator[](int i){
            if(i >= (int)sizeof(stops) || i < 0) throw std::out_of_range("Out of range!\n");
            return stops[i].getItem();
        }

        void addStop(char stop);
        char nextStop(char current)const;
        int getID()const{return packageId;}
};

#endif
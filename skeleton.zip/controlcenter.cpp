#include "package.h"
#include "path.h"
#include "belt.h"
#include "bfs.h"
#include "bfsData.h"
#include "controlcenter.h"
#include "junction.h"
#include "dinArray.h"

void CC::addJunction(Junction& j){
    junctions.add(j);
}

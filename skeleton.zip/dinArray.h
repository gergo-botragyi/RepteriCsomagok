#ifndef DINARRAY_H
#define DINARRAY_H

#include <typeinfo>
#include <stdexcept>
#include "memtrace.h"

template <typename T>
class dinItem{
    T item;
    dinItem<T>* next;

    public:
        dinItem(){next = nullptr;}
        dinItem(const T& newItem){item = newItem; next = nullptr;}

        T& getItem(){return item;}
        dinItem<T>* getNext(){return next;}

        template <typename U>
        friend class dinArray;
};

class bfsData;
class Junction;

template <typename T>
class dinArray{
    size_t n;
    dinItem<T>* arr;

    dinItem<T>* find(size_t i) const{
        if(i>=n) throw std::out_of_range("Out of range!\n");
        dinItem<T>* ret = arr;
        for (size_t j = 0; j < i; j++) {
            ret = ret->next;
        }
        return ret;
    }

    public:
        dinArray(size_t size = 0):n(size){
            arr = nullptr;

            for (size_t i = 0; i < n; i++)
            {
                dinItem<T>* moving = new dinItem<T>();
                moving->next = arr;
                arr = moving;
            }
        }

        void add(const T& item){
            dinItem<T>* last = new dinItem<T>(item);
            if(arr == nullptr){
                arr = last;
            }else{
                dinItem<T>* temp = arr;
                while (temp->next != nullptr) {
                    temp = temp->next;
                }
                temp->next = last;
            }
            n++;
        }

        void remove(size_t i){
            if(i>=n) throw std::out_of_range("Out of range!\n");
        
            if(i == 0){
                dinItem<T>* temp = arr->next; 
                delete arr;
                arr = temp;
            }
            else{
                dinItem<T>* prev = find(i-1);
                dinItem<T>* curr = prev->next;
                prev->next = curr->next;
                delete curr;
            }
            n--;
        }

        T pop(){
            dinItem<T>* temp = arr->next;
            T ret = arr->item;
            delete arr;
            arr = temp;
            n--;

            return ret;
        }

        bool search(const T& item){
            dinItem<T>* moving = arr;
            for (size_t i = 0; i < n; i++)
            {
                if(moving->item == item) return true;
                moving = moving->next;
            }
            return false;
        }

        template <typename K>
        dinItem<T>* find(const K& item)const{
            if(typeid(T) != typeid(K)) throw std::bad_typeid();
            dinItem<T>* ret = arr;
            while(ret->item != item || ret != nullptr){
                ret = ret->next;
            }
            return ret;
        }

        dinItem<bfsData>* findDataByChar(char item)const;
        Junction findJunctionByChar(char item)const;

        bool empty(){return arr == nullptr;}

        size_t size(){return n;}

        dinItem<T>& operator[](size_t i) { return *find(i);}

        const dinItem<T>& operator[](size_t i ) const{ return *find(i); }

        dinArray(const dinArray& dinarr){
            n = dinarr.n;
            arr = nullptr;

            dinItem<T>* source = dinarr.arr;
            dinItem<T>* last = nullptr;

            while (source != nullptr) {
                dinItem<T>* newItem = new dinItem<T>(source->item);
                if (arr == nullptr) {
                    arr = newItem;
                } else {
                    last->next = newItem;
                }
                last = newItem;
                source = source->next;
            }
        }

        dinArray& operator=(const dinArray& dinarr){
            if(this != &dinarr){
                dinItem<T>* curr = arr;
                while(curr != nullptr){
                    dinItem<T>* temp = curr->next;
                    delete curr;
                    curr = temp;
                }

                n = dinarr.n;
                arr = nullptr;

                dinItem<T>* source = dinarr.arr;
                dinItem<T>* last = nullptr;

                while (source != nullptr) {
                    dinItem<T>* newItem = new dinItem<T>(source->item);
                    if (arr == nullptr) {
                        arr = newItem;
                    } else {
                        last->next = newItem;
                    }
                    last = newItem;
                    source = source->next;
                }
            }
            return *this;
        }

        ~dinArray(){
            while (arr != nullptr) {
                dinItem<T>* next = arr->next;
                delete arr;
                arr = next;
            }
        }
};

#endif
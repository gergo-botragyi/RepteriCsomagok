#include <stdexcept>
#include "junction.h"
#include "package.h"
#include "belt.h"
#include "memtrace.h"
#include "dinArray.h"

Junction::Junction(const Junction& j){
    name = j.name;
    belts = j.belts;
    nOfBelts = j.nOfBelts;
    packages = j.packages;
    nOfPackages = j.nOfPackages;
}

Junction& Junction::operator=(const Junction& j){
    if(this != &j){
        name = j.name;
        belts = j.belts;
        nOfBelts = j.nOfBelts;
        packages = j.packages;
        nOfPackages = j.nOfPackages;
    }
    return *this;
}

bool Junction::existingPackage(Package& p){
    return packages.search(p);
}

bool Junction::existingBelt(Belt& b){
    return belts.search(b);
}

void Junction::addPackage(Package& p){
    if(existingPackage(p)) return;
    packages.add(p);
    nOfPackages++;
}

void Junction::addBelt(Belt& b){
    if(existingBelt(b)) return;
    belts.add(b);
    nOfBelts++;
}
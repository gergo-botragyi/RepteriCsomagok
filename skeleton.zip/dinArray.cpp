#ifndef DINARRAY_CPP
#define DINARRAY_CPP

#include "dinArray.h"
#include "bfsData.h"
#include "junction.h"

template <>
dinItem<bfsData>* dinArray<bfsData>::findDataByChar(char item)const{
    dinItem<bfsData>* ret = arr;
    while(ret->item.getJunction() != item && ret != nullptr){
        ret = ret->next;
    }
    return ret;
}

template <>
Junction dinArray<Junction>::findJunctionByChar(char item)const{
    dinItem<Junction>* ret = arr;
    while(ret->item.getName() != item && ret != nullptr){
        ret = ret->next;
    }
    return ret->item;
}

#endif
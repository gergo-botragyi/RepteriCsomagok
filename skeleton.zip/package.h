#ifndef PACKAGE_H
#define PACKAGE_H

class Package{
    int id;
    char start, destination;
    bool done;

    public:
        Package():id(-1), start('-'), destination('-'){}
        Package(int id, char start, char destination):id(id), start(start), destination(destination){}

        Package(const Package& p);
        bool operator==(const Package& p);

        bool arrived()const{return done;}
        int getId()const{return id;}
        char getStart()const{return start;}
        char getDest()const{return destination;}
};

#endif
#ifndef CONTROLLCENTER_H
#define CONTROLLCENTER_H

#include "package.h"
#include "path.h"
#include "belt.h"
#include "bfs.h"
#include "junction.h"
#include "bfsData.h"
#include "dinArray.h"

class CC{
    dinArray<Junction> junctions;
    dinArray<Path> paths;
    int nOfJunctions;
    int nOfPaths;
    dinArray<bfs> bfsArray;
    int nOfBFS;

    public:
        CC(): 
            junctions(dinArray<Junction>(0)), 
            paths(dinArray<Path>(0)), 
            nOfJunctions(0),
            nOfPaths(0), 
            bfsArray(dinArray<bfs>(0)), 
            nOfBFS(0)
        {}

        void addJunction(Junction& j);

        bool hasPath(int packageID)const;
        
        int nextBelt(const Package& p, const char junction, Belt* belts);
        
        void makeBFS(char junction);

        void run();
};

#endif
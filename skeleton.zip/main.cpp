#include <iostream>
#include <limits> // For std::numeric_limits
#include "belt.h"
#include "controlcenter.h"
#include "junction.h"
#include "package.h"
#include "path.h"
#include "memtrace.h"
#include "gtest_lite.h"

void test1(){
    TEST(test1, basics){
        Package p1(1, 'A', 'B');
        Package p2(2, 'B', 'C');
        Package p3(3, 'C', 'B');
        
        Belt ab(1, 'A', 'B');
        Belt ac(2, 'A', 'C');
        Belt bc(3, 'B', 'C');
        Belt ca(4, 'C', 'A');
        
        Junction A('A');
        Junction B('B');
        Junction C('C');
        
        A.addBelt(ab);
        A.addBelt(ac);
        
        EXPECT_EQ(2, A.getNOfBelts()) << "Number of belts\n";
        
        B.addBelt(bc);
        C.addBelt(ca);
        
        A.addPackage(p1);
        EXPECT_EQ(1, A.getNOfPackages()) << "Number of packages!\n";
        
        B.addPackage(p2);
        C.addPackage(p3);
        
        CC controller;
        controller.addJunction(A);
        controller.addJunction(B);
        controller.addJunction(C);

        std::cout << "Test1 success!\n";
    }END
}

void test2(){
    TEST(test2, bfs){
        Junction A('A');
        Junction B('B');
        Junction C('C');
        Junction D('D');
        Junction E('E');

        Belt ab(1, 'A', 'B');
        Belt ac(2, 'A', 'C');
        Belt bc(3, 'B', 'C');
        Belt ca(4, 'C', 'A');
        Belt cd(5, 'C', 'D');
        Belt de(6, 'D', 'E');
        Belt eb(7, 'E', 'B');

        A.addBelt(ab);
        A.addBelt(ac);
        B.addBelt(bc);
        C.addBelt(ca);
        C.addBelt(cd);
        D.addBelt(de);
        E.addBelt(eb);

        dinArray<Junction> junctions;
        junctions.add(A);
        junctions.add(B);
        junctions.add(C);
        junctions.add(D);
        junctions.add(E);

        bfs alg(A, 5);
        alg.createTable(junctions);
        std::cout<<"test2 success!\n";
    }END
}

template <typename T>
void input(T& t) {
    while (!(std::cin >> t)) { // Check if input fails
        std::cin.clear(); // Clear the error state
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
        std::cout << "Invalid input. Please try again: ";
    }
}

void test3(){
    TEST(test3, console){
        std::cout << "Name of junction 1 (one character):\n";
        char name1;
        input(name1);
        Junction one(name1);

        std::cout << "Name of junction 2 (one character):\n";
        char name2;
        input(name2);
        Junction two(name2);

        dinArray<Junction> junctions;
        junctions.add(one);
        junctions.add(two);

        std::cout << "Start of conveyor belt (one character):\n";
        char from, to;

        input(from);
        while(from != name1 && from != name2){
            std::cout << "The belt has to start at one of the junctions.\n";
            input(from);
        }

        std::cout << "End of conveyor belt (one character):\n";
        input(to);
        while((to != name1 && to != name2) || to == from){
            std::cout << "The belt has to end at the other junction.\n";
            input(to);
        }
        Belt belt1(1, from, to);

        if(from == name1){
            one.addBelt(belt1);
            bfs alg1(one, 2);
            alg1.createTable(junctions);
        }else{
            two.addBelt(belt1);
            bfs alg2(two, 2);
            alg2.createTable(junctions);
        }
        
        std::cout<<"test3 success!\n";
    }END
}

int main(){

    test1();
    test2();
    test3();

    return 0;
}

#include "belt.h"
#include "memtrace.h"

bool Belt::operator==(const Belt& b){
    return id == b.getId();
}

Belt::Belt(const Belt& b){
    id = b.id;
    start = b.start;
    end = b.end;
    nOfPackages = b.nOfPackages;
    packages = b.packages;
}
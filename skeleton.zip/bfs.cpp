#include "memtrace.h"
#include "bfs.h"
#include "dinArray.h"
#include "junction.h"

void bfs::createTable(dinArray<Junction>& junctions){ //BFS algoritmus
    //Eloszor elkesziti a tablat, ahol tarolja majd, hogy melyik csucsba honnan jottunk es mekkora a tavolsag
    //Az elsobe nyilvan 0 a tavolsag es sajat magabol "jon"
    table.add(bfsData(junction.getName(), 0, junction.getName()));
    table[0].getItem().display();

    //Az osszes tobbi csomoponthoz eleinte -1 a tav es sajat magabol "jon"
    dinItem<Junction> curr = junctions[0];
    for (size_t i = 0; i < junctions.size(); i++)
    {
        if(curr.getItem().getName() != junction.getName()){ //Ahonnan indul a BFS, azt a csucsot mar beletettuk
            table.add(bfsData(curr.getItem().getName(), -1, curr.getItem().getName()));
            table[table.size()-1].getItem().display(); //Megjelenites, CSAK TESZTHEZ
        }
        if(i<junctions.size()-1) curr = *curr.getNext();
    }
    

    //Ez igazabol a valodi algoritmus
    //Van egy visited lista, hogy mely csucsokban jartunk mar. Ennek szomszedait kell nezni
    //Ezen kivul van egy active csomopont ami az eppen aktualis csomopont
    Junction active;
    dinArray<Junction> visited;
    visited.add(junction);

    while(!visited.empty()){
        active = visited.pop(); //Active a visited elso eleme, amit ki is szed onnan, hiszen tobbszor nem kell megnezni
        dinItem<bfsData>* activeTableData = table.findDataByChar(active.getName()); //Ez ugyanaz az active, csak a tablaban levo
        for (int i = 0; i < active.getNOfBelts(); i++) //Az osszes szomszedon veigmegy
        {
            dinItem<bfsData> *currentJunction = table.findDataByChar(active.getBelt(i).getEnd()); //Eppen vizsgalt szomszed 
            if(currentJunction->getItem().distance == -1){ //Csak akkor kell viszgalni, ha meg nem jartuk be
                visited.add(junctions.findJunctionByChar(currentJunction->getItem().getJunction())); //Kesobb az aktualis szomszedot is vizsgalni kell majd

                currentJunction->getItem().distance = activeTableData->getItem().distance + 1; //Aktualis szomszed tavolsaga az active +1 mivel onnan jovunk
                currentJunction->getItem().prev = active.getName(); //Ahonnan erkeztunk, az nyilvan az active
            }
        }
    }

    //Vegeredmeny megejelenitese CSAK TESZTHEZ
    std::cout<<"\n";
    for (size_t i = 0; i < table.size(); i++)
    {
        table[i].getItem().display();
    }
    
}
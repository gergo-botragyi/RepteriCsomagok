#include "package.h"
#include "memtrace.h"

Package::Package(const Package& p){
    id = p.id;
    destination = p.destination;
    start = p.start;
}

bool Package::operator==(const Package& p){
    return id==p.id;
}
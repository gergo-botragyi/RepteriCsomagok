#ifndef BELT_H
#define BELT_H

#include "package.h"
#include "dinArray.h"

class Belt{
    int id;
    char start, end;
    dinArray<Package> packages;
    int nOfPackages;

    public:
        Belt():id(-1), start('-'), end('-'), packages(dinArray<Package>(0)), nOfPackages(0){}
        Belt(int id, char start, char end):id(id), start(start), end(end), packages(dinArray<Package>(0)), nOfPackages(0){}

        int getId()const{return id;}
        char getStart()const{return start;}
        char getEnd()const{return end;}

        Belt(const Belt& b);
        bool operator==(const Belt& b);

        void addPackage(Package pack);
        Package removePackage();
};

#endif
#ifndef BFSDATA_H
#define BFSDATA_H

#include <iostream>

struct bfsData{
    int distance;
    char prev;

    
    bfsData():distance(0), prev('-'){junction = '-';}
    bfsData(char junctionName, int distance, char previousName):distance(distance), prev(previousName){junction = junctionName;};


    char getJunction()const{return junction;}

    void display()const{
        std::cout << junction << "\t" << distance << "\t" << prev << "\n";
    }

    private:
        char junction;
};

#endif
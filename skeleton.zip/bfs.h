#ifndef BFS_H
#define BFS_H

#include "bfsData.h"
#include "dinArray.h"
#include "junction.h"

class bfs{
    Junction junction;
    dinArray<bfsData> table;
    int n;

    public:
        bfs():n(0){}
        bfs(Junction& junction, int n):junction(junction), n(n){}
        
        char getJunction()const { return junction.getName();}

        void createTable(dinArray<Junction>& junctions);
        char* makePath(char destination);

};

#endif
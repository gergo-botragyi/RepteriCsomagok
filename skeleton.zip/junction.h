#ifndef JUNCTION_H
#define JUNCTION_H

#include "package.h"
#include "belt.h"
#include "dinArray.h"

class Junction{
    char name;
    dinArray<Belt> belts;
    int nOfBelts;
    dinArray<Package> packages;
    int nOfPackages;

    public:
        Junction():name('-'),belts(dinArray<Belt>(0)), nOfBelts(0), packages(dinArray<Package>(0)), nOfPackages(0){}
        Junction(char name): name(name), belts(dinArray<Belt>(0)), nOfBelts(0), packages(dinArray<Package>(0)), nOfPackages(0){}
        
        char getName()const{return name;}
        Package getNextPackage()const;
        Belt getBelt(int i){return belts[i].getItem();}

        Junction(const Junction& j);
        Junction& operator=(const Junction& j);

        int getNOfBelts()const {return nOfBelts;}
        int getNOfPackages()const{return nOfPackages;}

        void addBelt(Belt& b);
        void addPackage(Package& p);
        bool existingPackage(Package& p);
        bool existingBelt(Belt& b);

        void send(int packageID, int beltID);
};

#endif